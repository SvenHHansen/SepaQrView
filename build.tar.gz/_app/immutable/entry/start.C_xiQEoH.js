import{a as t}from"../chunks/entry.COGyViIj.js";export{t as start};
